#include "filtre.hpp"
//Pas de définition de méthode/contructeur longue.